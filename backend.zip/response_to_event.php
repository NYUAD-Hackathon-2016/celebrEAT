<?php

	include_once 'database_connection.php';
	
	session_start();
	
	$response = $_POST['response'];
	
	$event_id = $_POST['event_id'];
	
	$sql = "UPDATE `event` SET `status` = '".$response."' WHERE `event`.`id` = ".$event_id;

	if(mysql_query($sql)){
		echo 'success';
	}else{
		echo mysql_error();
	}
	
	
	
?>