<?php
include_once 'database_connection.php';


session_start();

$chef_id = $_SESSION['id'];
$photo =  $_POST['photo']; 

$title = $_POST['title'];
$small_description = $_POST['small_description'];
$ingredients = $_POST['ingredients'];

$menu_id = $_SESSION['menu_id'];

$sql = "INSERT INTO Dish (photo,chef_id,title,small_description,ingredients,menu_id) VALUES ('".$photo."','".$chef_id."','".$title."','".$small_description."','".$ingredients."','".$menu_id."')";

if(mysql_query($sql)){
	echo 'success';
}else{
	echo mysql_error();
}

?>