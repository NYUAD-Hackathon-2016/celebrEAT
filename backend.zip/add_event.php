<?php

//give menu_id,time,date

include_once 'database_connection.php';

session_start();



$menu_id = $_GET['menu_id'];

	$sql = "select * from Menu where id=".$menu_id;
	$result = mysql_query($sql);
	$result = mysql_fetch_array($result);
$chef_id = $result['chef_id'];

$sql = "select * from chef where id=".$chef_id;
	$result = mysql_query($sql);
	$result = mysql_fetch_array($result);

$chef_location = $result['location'];

$sql = "select * from host where id=".$_SESSION['id'];
	$result = mysql_query($sql);
	$result = mysql_fetch_array($result);
	$host_id = $result['id'];

$event_location = $result['location'];

$time = $_GET['time'];
$date = $_GET['date'];

$status = "pending";


$sql = "insert into event (chef_id,host_id,menu_id,chef_location,event_location,time,date,status) VALUE ('".$chef_id."','".$host_id."','".$menu_id."','".$chef_location."','".$event_location."','".$time."','".$date."','".$status."')";

if(mysql_query($sql)){
	echo 'success';
}else{
	echo mysql_error();
}
	
?>