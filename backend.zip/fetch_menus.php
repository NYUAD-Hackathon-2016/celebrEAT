<?php

include_once 'database_connection.php';



$sql = "select * from Menu";

$result = mysql_query($sql);

$result2 = array();



	while($row = mysql_fetch_array($result)){
		$arr_dishes = array();

		$sql = "select * from Dish where menu_id=".$row['id'];
		$res = mysql_query($sql);
		while($r = mysql_fetch_array($res)){
		
			array_push($arr_dishes,$r);
		}
		
		
		
		
		$sql = "select * from chef where id=".$row['chef_id'];
		$arr_chef = mysql_query($sql);
		$arr_chef = mysql_fetch_array($arr_chef);
		
	
		
		$row['chef_id'] = $arr_chef;
		
		array_push($row,$arr_dishes);
		
		
		array_push($result2,$row);
	}
	
	
	echo json_encode($result2);



?>