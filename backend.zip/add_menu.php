<?php
include_once 'database_connection.php';
ini_set('file_uploads', '1');


session_start();



$chef_id = $_SESSION['id'];
$photo =  $_POST['photo']; 



//echo $photo

$serves = $_POST['serves'];

$name = $_POST['name'];

$sql = "insert into Menu (chef_id,photo,name,serves) VALUES ('".$chef_id."','".$photo."','".$name."','".$serves."')";

if(mysql_query($sql)){
	
			$sql = "select LAST_INSERT_ID() as id";

		$result = mysql_query($sql);
		$result = mysql_fetch_array($result);

		$menu_id = $result['id'];
	
		$_SESSION['menu_id'] = $menu_id;
	
	echo 'success';
}else{
//	echo mysql_error();
}


?>