<?php

include_once 'database_connection.php';




if( isset($_POST['email']) && isset($_POST['password'])){
	
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	$sql = "select * from `host` where email='".$email."' and password='".$password."'";

	$result = mysql_query($sql);
	
	
	if(mysql_num_rows($result) > 0){
		signin_host();
	}
	
	$sql = "select * from `chef` where email='".$email."' and password='".$password."'";

	$result = mysql_query($sql);
	
	if(mysql_num_rows($result) > 0){
		signin_chef();
	}else{
		
	}
	
	
}else{
	
	echo 'not set';
}

function signin_host(){
	$email = $_POST['email'];
	$password = $_POST['password'];

	
	$sql = "select * from `host` where email='".$email."' and password='".$password."'";

	$result = mysql_query($sql);
	
	
			
	if(mysql_num_rows($result) > 0){
			$row = mysql_fetch_array($result);

			session_start();
			
			$_SESSION['id'] =  $row['id'];
			$_SESSION['role'] = 'host';
			
			echo 'host';

	}else{
		
		echo 'not found';
	}
}

function signin_chef(){
	$email = $_POST['email'];
	$password = $_POST['password'];

	
	$sql = "select * from `chef` where email='".$email."' and password='".$password."'";

	$result = mysql_query($sql);
	
	
			
	if(mysql_num_rows($result) > 0){
			$row = mysql_fetch_array($result);

			session_start();
			
			$_SESSION['id'] =  $row['id'];
			$_SESSION['role'] = 'chef';
			
			echo 'chef';

	}else{
		echo 'not found';
	}
}

?>