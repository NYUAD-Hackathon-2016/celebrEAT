<?php

include_once 'database_connection.php';

if(isset($_POST['type'])){
	if($_POST['type'] == 'chef'){
		signup_chef();
	}else{
		signup_host();
	}
}

function signup_host(){
		$name = $_POST['name'];
		$language = $_POST['language'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$location = $_POST['location'];
		$phone = $_POST['phone'];
		
		$sql = "INSERT INTO `host` ( `name`, `language`, `email`, `password`, `location`, `phone`) VALUES ( '".$name."', '".$language . "', '".$email."','".$password."','".$location."', '".$phone."')";
		
		if(mysql_query($sql)){
			echo 'success';
		}else{
			echo mysql_error();
		}

}

function signup_chef(){
		$name = $_POST['name'];
		$origin = $_POST['origin'];
		$story = $_POST['story'];
		$languages = $_POST['languages'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$location = $_POST['location'];
		$phone = $_POST['phone'];
		
		$profile_photo =  $_POST['profile_photo']; 
	//	$profile_photo = $_POST['profile_photo'];

	
		$sql = "INSERT INTO `chef` (`profile_photo` , `origin`, `story`, `languages`, `email`, `password`, `location`, `phone`, `name`) VALUES ('".$profile_photo."', '".$origin."', '".$story . "', '".$languages."','".$email."','".$password."', '".$location."', '".$phone."','".$name."')";
		
		if(mysql_query($sql)){
			echo 'success inserted chef';
		}else{
			echo mysql_error();
		}
		
}


?>