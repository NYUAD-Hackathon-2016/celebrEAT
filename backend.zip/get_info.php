<?php

include_once 'database_connection.php';

session_start();


if(isset($_SESSION['role']) && isset($_SESSION['id'])){
	
	if($_SESSION['role'] == 'chef'){
		POST_chef_info();
	}else{
		POST_host_info();
	}
	
}


function POST_chef_info(){
	$id = $_SESSION['id'];
	
	$sql = "select * from chef where id=".$id;
	
	$result = mysql_query($sql);
	$result1 = mysql_fetch_array($result);
	
		
	$sql = "select * from event where chef_id=".$id;
	
	$result = mysql_query($sql);
	
		$result2 = array();


	while($row = mysql_fetch_array($result)){
		array_push($result2,$row);
	}
	
	$sql = "select * from Menu where chef_id=".$id;

	

	
	$result3 = array();
	
	$result = mysql_query($sql);

	while($row = mysql_fetch_array($result)){
		
		$arr_dishes = array();
			
			
		$sql = "select * from Dish where menu_id=".$row['id'];
		$res = mysql_query($sql);
		
		
			if(mysql_num_rows($res) > 0){	
				while($r = mysql_fetch_array($res)){
					array_push($arr_dishes,$r);
				}
				
				array_push($row,$arr_dishes);
			}	
			
		array_push($result3,$row);
	}
	
	
	
	
	$result =  array();
	
		array_push($result,$result1,$result2,$result3);
	

	
		$json = json_encode($result);
		
		

		
		echo $json;
	
}

function POST_host_info(){
		$id = $_SESSION['id'];
	
	$sql = "select * from host where id=".$id;
	
	$result = mysql_query($sql);
	$result = mysql_fetch_array($result);

	
		$json = json_encode($result);

		
		echo $json;
}

?>