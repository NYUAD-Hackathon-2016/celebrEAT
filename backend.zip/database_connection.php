<?php
	

	
$username = "root";
$password = "";
$hostname = "localhost"; 

//connection to the database
$dbhandle = mysql_connect($hostname, $username, $password )
  or die("Unable to connect to MySQL");
//echo "Connected to MySQL<br>";

mysql_select_db('celebreat');

 header('Access-Control-Allow-Origin: http://localhost:8000');  

 header('Access-Control-Allow-Credentials: true');	



?>